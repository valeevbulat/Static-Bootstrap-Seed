# Static-Bootstrap-Seed
Bootstrap 3, jQuery, Less  

- css
  - bootstrap.min.css (v3.3.6)
  - main.less
  - vars.less
  - components.less
  - sections.less
  - fonts.less
  - tags.less
- js
  - bootstrap.min.js (v3.3.6)
  - jquery.min.js (v1.12.2)
- images
  - media
  - icons
- fonts 
  - (glyphicon-fonts)

index.html
