
var coord = ['',
    {
        top: '200px',
        left: '-70px'
    },
    {
        top: '530px',
        left: '125px'
    },
    {
        top: '-30px',
        left: '390px'
    },
    {
        top: '100px',
        left: '1130px'
    },
    {
        top: '430px',
        left: '1130px'
    },
    {
        top: '108%',
        left: '50%'
    },
    {
        top: '25%',
        left: '19%'
    },
    {
        top: '54%',
        left: '15%'
    },
    {
        top: '81%',
        left: '17%'
    },
    {
        top: '35%',
        left: '33%'
    },
    {
        top: '71%',
        left: '36%'
    },
    {
        top: '32%',
        left: '53%'
    },
    {
        top: '73%',
        left: '56%'
    },
    {
        top: '40%',
        left: '79%'
    },
    {
        top: '74%',
        left: '75%'
    },
    {
        top: '50%',
        left: '80%'
    }
]

// for(var i=1; i < coord.length; i++){
//     $('#scene').append('<li class="layer" data-depth="0.'+(i*2)+'0"><img src="./images/elements/el-'+ i +'.png" id="element-'+ i +'" ></li>');
// }

// $('#body').mousemove(function (e) {
//    console.log(e.pageX + ' ' + e.clientX);
// });